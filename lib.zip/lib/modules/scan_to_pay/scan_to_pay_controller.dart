
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:aesera_jewels/modules/dashboard/dashboard_view.dart';

class ScanToPayController extends GetxController {
  // Track if the payment is completed or not
  final paymentCompleted = false.obs;

  // This function handles the "Proceed" button press
  void onProceed() {
    if (!paymentCompleted.value) {
      // If payment is not completed, show a confirmation dialog
      _showPaymentDialog();
    } else {
      // If payment is completed, navigate back to the Dashboard screen
      Get.to(() => DashboardScreen());
    }
  }

  // Show a dialog confirming the payment completion
  void _showPaymentDialog() {
    Get.dialog(
      Center(
        child: Container(
          width: MediaQuery.of(Get.context!).size.width * 0.9,
          height: MediaQuery.of(Get.context!).size.height * 0.2,
          padding: EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Color(0xFF0A2A4D),
            borderRadius: BorderRadius.circular(16),
          ),
          alignment: Alignment.center,
          child: Text(
            "Your Payment Has Been\nSuccessfully Completed",
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white, fontSize: 18),
          ),
        ),
      ),
      barrierDismissible: true,
    ).then((_) {
      // Update the paymentCompleted state after dialog is closed
      paymentCompleted.value = true;
    });
  }
  
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }
}
