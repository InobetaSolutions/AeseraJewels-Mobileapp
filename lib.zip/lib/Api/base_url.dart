class BaseUrl {
  static const String baseUrl = 'http://13.204.96.244:3000/api/';
}
class ImageUrl {
  static const String imageUrl = 'http://13.204.96.244:3000/api/uploads/';
}